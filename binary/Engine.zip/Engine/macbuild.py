import os

COMPILER = "g++"
SOURCE = "./src/*.cpp"
ARGUMENTS = "-D MAC -std=c++14 -shared -undefined dynamic_lookup -rpath /Library/Frameworks/"
INCLUDE_DIR = "-I ./include/ -I./pybind11/include/ -I/Library/Frameworks/SDL2.framework/Headers -I/Library/Frameworks/SDL2_ttf.framework/Headers `python3.9 -m pybind11 --includes`"
LIBRARIES = "-F/Library/Frameworks -framework SDL2 -framework SDL2_ttf `python3.9-config --ldflags`"
EXECUTABLE = "mygameengine.so"

compileString = COMPILER + " " + ARGUMENTS + " -o " + EXECUTABLE + " " + INCLUDE_DIR + " " + SOURCE + " " + LIBRARIES

print(compileString)
os.system(compileString)
