var searchData=
[
  ['burntime_0',['burnTime',['../class_bush_1_1_bush.html#ad1f4396af45455083745e72af5fd27fb',1,'Bush.Bush.burnTime()'],['../class_wood_1_1_wood.html#a4531eae3cd85132ccbc1e10bed03d4a9',1,'Wood.Wood.burnTime()']]]
];
