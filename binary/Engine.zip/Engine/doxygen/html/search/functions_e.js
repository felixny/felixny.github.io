var searchData=
[
  ['_7eresourcemanager_0',['~ResourceManager',['../class_resource_manager.html#a671c186e4630599e7e36d000c53eaf80',1,'ResourceManager']]],
  ['_7esdlgraphicsprogram_1',['~SDLGraphicsProgram',['../class_s_d_l_graphics_program.html#a2504412e7eaa011a1116447eb4d5ec00',1,'SDLGraphicsProgram']]]
];
