var searchData=
[
  ['name_0',['name',['../class_bush_1_1_bush.html#abbca5f0de90c9e9087abc4ef01ca6a37',1,'Bush.Bush.name()'],['../class_character_1_1_character.html#ab1abeeebd70c10c7b963705e9565a671',1,'Character.Character.name()'],['../class_fire_1_1_fire.html#a07bbb601e82f26b71bd8b9d30b7fc2b0',1,'Fire.Fire.name()'],['../class_game_object_1_1_game_object.html#aed48e973734a57b66ecc4a97f25fb65d',1,'GameObject.GameObject.name()'],['../class_water_1_1_water.html#ad974aaefbd1511a900dd7258a3d2deaa',1,'Water.Water.name()'],['../class_wood_1_1_wood.html#ab99574c253a6d7a1dbdc23b363c77557',1,'Wood.Wood.name()']]]
];
