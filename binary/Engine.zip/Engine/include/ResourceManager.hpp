#ifndef RESOURCE_MANAGER_HPP
#define RESOURCE_MANAGER_HPP

#if defined(LINUX) || defined(MINGW)
#include <SDL2/SDL.h>
#else  // This works for Mac
#include <SDL.h>
#endif

// I recommend a map for filling in the resource manager
#include <mutex>
#include <string>
#include <thread>
#include <unordered_map>

/**
 * @brief A class for managing resources, such as images and audio files
 */
class ResourceManager {
 public:
  /**
   * @brief Destructor
   * 
   * In theory, this is never called
   */
  ~ResourceManager();

  /**
   * @brief Loads an image resource from a file
   * 
   * @param image_filename The name of the image file to be loaded
   */
  void LoadResource(std::string image_filename);

  /**
   * @brief Returns an SDL surface containing the specified image resource
   * 
   * @param image_filename The name of the image resource to be returned
   * @return An SDL surface containing the specified image resource
   */
  SDL_Surface* GetResource(std::string image_filename);

  /**
   * @brief Loads an image resource as a texture
   * 
   * @param renderer The renderer to be used for creating the texture
   */
  void LoadTexture(SDL_Renderer* renderer);

  /**
   * @brief Returns a texture containing the specified image resource
   * 
   * @param renderer The renderer to be used for creating the texture
   * @param image_filename The name of the image resource to be returned
   * @return A texture containing the specified image resource
   */
  SDL_Texture* GetTexture(SDL_Renderer* renderer, std::string image_filename);

  /**
   * @brief Returns the singleton instance of the ResourceManager class
   * 
   * @return The singleton instance of the ResourceManager class
   */
  static ResourceManager& GetInstance();

  /**
   * @brief Destroys the singleton instance of the ResourceManager class
   */
  void Destroy();

  /**
   * @brief Initializes the resource manager
   * 
   * @return 0 on success, -1 on failure
   */
  int StartUp();

  /**
   * @brief Shuts down the resource manager
   * 
   * @return 0 on success, -1 on failure
   */
  int ShutDown();

  /**
   * @brief Prints a message to the console
   */
  void printMessage();

  /**
   * @brief Loads an audio resource from a file
   * 
   * @param audio_filename The name of the audio file to be loaded
   */
  void LoadAudio(std::string audio_filename);

  /**
   * @brief Plays the currently loaded audio resource
   */
  void PlayAudio();

  /**
   * @brief Stops playing the currently loaded audio resource
   */
  void StopAudio();

  /**
   * @brief Deleted copy constructor
   */
  ResourceManager(const ResourceManager&) = delete;

  /**
   * @brief Deleted copy assignment operator
   */
  ResourceManager& operator=(const ResourceManager&) = delete;

 private:
  ResourceManager(); /**< Private constructor */
  SDL_Surface* mSpriteSheet; /**< The sprite sheet surface */
  SDL_Texture* mTexture; /**< The texture created from the sprite sheet surface */
  std::string mFile; /**< The file name of the sprite sheet */
  int num = 0; /**< An integer variable for testing purposes */
  std::unordered_map<std::string, SDL_AudioSpec> audioMap; /**< A map of audio specifications */
  SDL_AudioSpec wavSpec; /**< The audio specification of the currently loaded audio file */
  Uint32 wavLength; /**< The length of the currently loaded audio file */
  Uint8* wavBuffer; /**< The buffer containing the audio data of the currently loaded audio file */
  SDL_AudioDeviceID deviceId; /**< The ID of the audio device */
  std::mutex map_mutex; /**< A mutex for accessing the audio map safely */
  std::unordered_map<std::string, SDL_Surface*> loaded_resources;/**< A map of all the loaded resources */
  std::unordered_map<std::string, SDL_Texture*> loaded_textures;/**< A map of all the loaded textures */
};

#endif
