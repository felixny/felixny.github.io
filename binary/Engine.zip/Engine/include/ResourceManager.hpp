#ifndef RESOURCE_MANAGER_HPP
#define RESOURCE_MANAGER_HPP

#if defined(LINUX) || defined(MINGW)
#include <SDL2/SDL.h>
#else  // This works for Mac
#include <SDL.h>
#endif

// I recommend a map for filling in the resource manager
#include <mutex>
#include <string>
#include <thread>
#include <unordered_map>

class ResourceManager {
 public:
  // Destructor
  // In theory, this is never called
  ~ResourceManager();
  void LoadResource(std::string image_filename);
  SDL_Surface* GetResource(std::string image_filename);
  void LoadTexture(SDL_Renderer* renderer);
  SDL_Texture* GetTexture(SDL_Renderer* renderer, std::string image_filename);
  static ResourceManager& GetInstance();
  void Destroy();

  // 'equivalent' to our constructor
  int StartUp();

  // 'equivalent' to our destructor
  int ShutDown();
  void printMessage();
  void LoadAudio(std::string audio_filename);
  void PlayAudio();
  void StopAudio();

  ResourceManager(const ResourceManager&) = delete;
  ResourceManager& operator=(const ResourceManager&) = delete;

 private:
  SDL_Surface* mSpriteSheet;
  ResourceManager();
  SDL_Texture* mTexture;
  std::string mFile;
  int num = 0;
  std::unordered_map<std::string, SDL_AudioSpec> audioMap;
  SDL_AudioSpec wavSpec;
  Uint32 wavLength;
  Uint8* wavBuffer;
  SDL_AudioDeviceID deviceId;
  std::mutex map_mutex;
  std::unordered_map<std::string, SDL_Surface*> loaded_resources;
  std::unordered_map<std::string, SDL_Texture*> loaded_textures;
};

#endif
