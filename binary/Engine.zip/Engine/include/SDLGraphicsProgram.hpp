#ifndef SDLGRAPHICSPROGRAM
#define SDLGRAPHICSPROGRAM

// ==================== Libraries ==================
// Depending on the operating system we use
// The paths to SDL are actually different.
// The #define statement should be passed in
// when compiling using the -D argument.
// This gives an example of how a programmer
// may support multiple platforms with different
// dependencies.
#if defined(LINUX) || defined(MINGW)
    #include <SDL2/SDL.h>
#else // This works for Mac
    #include <SDL.h>
    #include <SDL_ttf.h>
#endif

// The glad library helps setup OpenGL extensions.
#include <glad/glad.h>

#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <vector>
// Include the pybindings
#include <pybind11/pybind11.h>

namespace py = pybind11;


#include "ResourceManager.hpp"

/**
 * @brief The SDLGraphicsProgram class sets up a full graphics program using SDL.
 */
class SDLGraphicsProgram {
public:
    /**
     * @brief Constructs an SDLGraphicsProgram object.
     *
     * @param w The width of the window to be created.
     * @param h The height of the window to be created.
     */
    SDLGraphicsProgram(int w, int h);

    /**
     * @brief Destructs an SDLGraphicsProgram object.
     */
    ~SDLGraphicsProgram();

    /**
     * @brief Initializes OpenGL.
     *
     * @return true if successful, false otherwise.
     */
    bool initGL();

    /**
     * @brief Clears the screen.
     */
    void clear();

    /**
     * @brief Flips to new buffer.
     */
    void flip();

    /**
     * @brief Delays rendering.
     *
     * @param milliseconds The time to delay in milliseconds.
     */
    void delay(int milliseconds);

    /**
     * @brief Runs the program loop indefinitely.
     */
    void loop();

    /**
     * @brief Gets a pointer to the SDL window.
     *
     * @return A pointer to the SDL window.
     */
    SDL_Window* getSDLWindow();

    /**
     * @brief Draws a simple rectangle.
     *
     * @param x The x coordinate of the rectangle.
     * @param y The y coordinate of the rectangle.
     * @param w The width of the rectangle.
     * @param h The height of the rectangle.
     */
    void DrawRectangle(int x, int y, int w, int h);

    /**
     * @brief Draws a rectangle with color.
     *
     * @param x The x coordinate of the rectangle.
     * @param y The y coordinate of the rectangle.
     * @param w The width of the rectangle.
     * @param h The height of the rectangle.
     * @param rgb The RGB color value of the rectangle.
     * @param fill Whether or not to fill the rectangle.
     */
    void DrawRectangleColor(int x, int y, int w, int h, uint32_t rgb, bool fill);

    /**
     * @brief Draws an image.
     *
     * @param x The x coordinate of the image.
     * @param y The y coordinate of the image.
     * @param w The width of the image.
     * @param h The height of the image.
     * @param image_filename The file name of the image to be drawn.
     */
    void DrawImage(int x, int y, int w, int h, std::string image_filename);

    /**
     * @brief Draws text.
     *
     * @param x The x coordinate of the text.
     * @param y The y coordinate of the text.
     * @param text The text to be drawn.
     * @param size The size of the text.
     */
    void DrawText(int x, int y, std::string text, int size);

    /**
 * @brief Draws a sprite image on the screen
 * 
 * @param x The x coordinate of the sprite's top-left corner
 * @param y The y coordinate of the sprite's top-left corner
 * @param w The width of the sprite
 * @param h The height of the sprite
 * @param image_filename The file name of the image to be used as the sprite
 * @param char_width The width of each character in the sprite sheet
 * @param char_height The height of each character in the sprite sheet
 * @param row The row of the character in the sprite sheet
 * @param col The column of the character in the sprite sheet
 */
void DrawSpriteImage(int x, int y, int w, int h, std::string image_filename, int char_width, int char_height, int row, int col);

/**
 * @brief Updates the input states (keys, mouse, etc.)
 */
void updateInputs();

/**
 * @brief Returns whether the left key is pressed or not
 * @return True if the left key is pressed, false otherwise
 */
bool getLeft();

/**
 * @brief Returns whether the right key is pressed or not
 * @return True if the right key is pressed, false otherwise
 */
bool getRight();

/**
 * @brief Returns whether the up key is pressed or not
 * @return True if the up key is pressed, false otherwise
 */
bool getUp();

/**
 * @brief Returns whether the down key is pressed or not
 * @return True if the down key is pressed, false otherwise
 */
bool getDown();

/**
 * @brief Returns whether the space key is pressed or not
 * @return True if the space key is pressed, false otherwise
 */
bool getSpace();

/**
 * @brief Returns whether the R key is pressed or not
 * @return True if the R key is pressed, false otherwise
 */
bool getR();

/**
 * @brief Returns whether the mouse button is clicked or not
 * @return True if the mouse button is clicked, false otherwise
 */
bool getMouseClicked();

/**
 * @brief Returns the position of the mouse on the screen
 * @return A pair of integers representing the x and y coordinates of the mouse
 */
std::pair<int,int> getMousePos();

/**
 * @brief Returns whether the application is being closed or not
 * @return True if the application is being closed, false otherwise
 */
bool getQuit();

/**
 * @brief Plays the specified audio file
 * 
 * @param audio_name The name of the audio file to be played
 */
void PlayAudio(std::string audio_name);

/**
 * @brief Stops playing the current audio file
 */
void StopAudio();

/**
 * @brief Keeps track of which keys are being pressed
 */
bool m_keys[8] = {false};

/**
 * @brief Screen dimension constants
 */
int screenHeight;

/**
 * @brief Screen dimension constants
 */
int screenWidth;

/**
 * @brief The window to be rendered to
 */
SDL_Window* gWindow;

/**
 * @brief The renderer
 */
SDL_Renderer* gRenderer;

};

#endif