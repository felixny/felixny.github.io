#ifndef SDLGRAPHICSPROGRAM
#define SDLGRAPHICSPROGRAM

// ==================== Libraries ==================
// Depending on the operating system we use
// The paths to SDL are actually different.
// The #define statement should be passed in
// when compiling using the -D argument.
// This gives an example of how a programmer
// may support multiple platforms with different
// dependencies.
#if defined(LINUX) || defined(MINGW)
    #include <SDL2/SDL.h>
#else // This works for Mac
    #include <SDL.h>
    #include <SDL_ttf.h>
#endif

// The glad library helps setup OpenGL extensions.
#include <glad/glad.h>

#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <vector>
// Include the pybindings
#include <pybind11/pybind11.h>

namespace py = pybind11;


#include "ResourceManager.hpp"
// Purpose:
// This class sets up a full graphics program using SDL
//
//
//
class SDLGraphicsProgram{
public:

    // Constructor
    SDLGraphicsProgram(int w, int h);
    // Destructor
    ~SDLGraphicsProgram();
    // Setup OpenGL
    bool initGL();
    // Clears the screen
    void clear();
    // Flips to new buffer
    void flip();
    // Delay rendering
    void delay(int milliseconds);
    // loop that runs forever
    void loop();
    // Get Pointer to Window
    SDL_Window* getSDLWindow();
    // Draw a simple rectangle
    void DrawRectangle(int x, int y, int w, int h);
    
    void DrawRectangleColor(int x, int y, int w, int h, uint32_t rgb, bool fill);

    void DrawImage(int x, int y, int w, int h, std::string image_filename);

    void DrawText(int x, int y, std::string text, int size);

    void DrawSpriteImage(int x, int y, int w, int h, std::string image_filename, int char_width, int char_height, int row, int col);

    void updateInputs();

    bool getLeft();

    bool getRight();

    bool getUp();

    bool getDown();

    bool getSpace();

    bool getR();

    bool getMouseClicked();

    std::pair<int,int> getMousePos();

    bool getQuit();

    void PlayAudio(std::string audio_name);
    void StopAudio();

private:
    // Keeps track of which keys are being pressed
    bool m_keys[8] = {false};
    // Screen dimension constants
    int screenHeight;
    int screenWidth;
    // The window we'll be rendering to
    SDL_Window* gWindow ;
    // Our renderer
    SDL_Renderer* gRenderer;
};

#endif