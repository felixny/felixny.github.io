#include "SDLGraphicsProgram.hpp"

// Initialization function
// Returns a true or false value based on successful completion of setup.
// Takes in dimensions of window.
SDLGraphicsProgram::SDLGraphicsProgram(int w, int h)
    : screenWidth(w), screenHeight(h) {
  // Initialization flag
  bool success = true;
  // String to hold any errors that occur.
  std::stringstream errorStream;
  // The window we'll be rendering to
  gWindow = NULL;
  // Render flag

  // Initialize SDL
  if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) < 0) {
    errorStream << "SDL could not initialize! SDL Error: " << SDL_GetError()
                << "\n";
    success = false;
  } else {
    // Create window
    gWindow = SDL_CreateWindow("Lab", 100, 100, screenWidth, screenHeight,
                               SDL_WINDOW_SHOWN);

    // Check if Window did not create.
    if (gWindow == NULL) {
      errorStream << "Window could not be created! SDL Error: "
                  << SDL_GetError() << "\n";
      success = false;
    }

    // Create a Renderer to draw on
    gRenderer = SDL_CreateRenderer(gWindow, -1, SDL_RENDERER_ACCELERATED);
    // Check if Renderer did not create.
    if (gRenderer == NULL) {
      errorStream << "Renderer could not be created! SDL Error: "
                  << SDL_GetError() << "\n";
      success = false;
    }
  }

  // If initialization did not work, then print out a list of errors in the
  // constructor.
  if (!success) {
    errorStream
        << "SDLGraphicsProgram::SDLGraphicsProgram - Failed to initialize!\n";
    std::string errors = errorStream.str();
    SDL_Log("%s\n", errors.c_str());
  } else {
    SDL_Log(
        "SDLGraphicsProgram::SDLGraphicsProgram - No SDL, GLAD, or OpenGL, "
        "errors detected during initialization\n\n");
  }

  // Initialize SDL_ttf
  if (TTF_Init() == -1) {
    printf("Failed to initialize SDL_ttf! SDL_ttf Error: %s\n", TTF_GetError());
    // Handle initialization error
    return;
  }
}

// Proper shutdown of SDL and destroy initialized objects
SDLGraphicsProgram::~SDLGraphicsProgram() {
  // Destroy window
  SDL_DestroyWindow(gWindow);
  // Point gWindow to NULL to ensure it points to nothing.
  gWindow = NULL;
  // Quit SDL subsystems
  SDL_Quit();
}

// Initialize OpenGL
// Setup any of our shaders here.
bool SDLGraphicsProgram::initGL() {
  // Success flag
  bool success = true;

  return success;
}

// clear
// Clears the screen
void SDLGraphicsProgram::clear() {
  // Nothing yet!
  SDL_SetRenderDrawColor(gRenderer, 0x44, 0x44, 0x4, 0xFF);
  SDL_RenderClear(gRenderer);
}
// Flip
// The flip function gets called once per loop
// It swaps out the previvous frame in a double-buffering system
void SDLGraphicsProgram::flip() {
  // Nothing yet!
  SDL_RenderPresent(gRenderer);
}

void SDLGraphicsProgram::delay(int milliseconds) { SDL_Delay(milliseconds); }

// Loops forever!
void SDLGraphicsProgram::loop() {
  // Main loop flag
  // If this is quit = 'true' then the program terminates.
  bool quit = false;
  // Event handler that handles various events in SDL
  // that are related to input and output
  SDL_Event e;
  // Enable text input
  SDL_StartTextInput();
  // While application is running
  while (!quit) {
    // Handle events on queue
    while (SDL_PollEvent(&e) != 0) {
      // User posts an event to quit
      // An example is hitting the "x" in the corner of the window.
      if (e.type == SDL_QUIT) {
        quit = true;
        break;
      }
    }  // End SDL_PollEvent loop.

    // Update screen of our specified window
    SDL_GL_SwapWindow(getSDLWindow());
  }

  // Disable text input
  SDL_StopTextInput();
}

// Get Pointer to Window
SDL_Window* SDLGraphicsProgram::getSDLWindow() { return gWindow; }

// Okay, render our rectangles!
void SDLGraphicsProgram::DrawRectangle(int x, int y, int w, int h) {
  SDL_Rect fillRect = {x, y, w, h};
  SDL_SetRenderDrawColor(gRenderer, 0xFF, 0xFF, 0xFF, 0xFF);
  SDL_RenderDrawRect(gRenderer, &fillRect);
  SDL_RenderFillRect(gRenderer, &fillRect);
}

void SDLGraphicsProgram::DrawRectangleColor(int x, int y, int w, int h,
                                            uint32_t rgb, bool fill) {
  SDL_Rect fillRect = {x, y, w, h};
  uint8_t red = rgb >> 16;
  uint8_t green = rgb >> 8;
  uint8_t blue = rgb;
  SDL_SetRenderDrawColor(gRenderer, red, blue, green, 0xFF);
  SDL_RenderDrawRect(gRenderer, &fillRect);
  if (fill) {
    SDL_RenderFillRect(gRenderer, &fillRect);
  }
}

void SDLGraphicsProgram::DrawImage(int x, int y, int w, int h,
                                   std::string image_filename) {
  ResourceManager::GetInstance().LoadResource("Assets/Sprites/" +
                                              image_filename);
  SDL_Texture* image = ResourceManager::GetInstance().GetTexture(
      gRenderer, "Assets/Sprites/" + image_filename);

  SDL_Rect mDest;
  mDest.x = x;
  mDest.y = y;
  mDest.w = w;
  mDest.h = h;

  SDL_RenderCopy(gRenderer, image, NULL, &mDest);
}

void SDLGraphicsProgram::DrawText(int x, int y, std::string text, int size) {
  // Load font
  SDL_Color color = {0, 0, 0, 255};

  TTF_Font* ttffont = TTF_OpenFont("Assets/Fonts/lazy.ttf", 28);
  if (ttffont == NULL) {
    printf("Failed to load font! SDL_ttf Error: %s\n", TTF_GetError());
    return;
  }
  SDL_Surface* surfaceMessage =
      TTF_RenderText_Solid(ttffont, text.c_str(), color);
  SDL_Texture* message =
      SDL_CreateTextureFromSurface(gRenderer, surfaceMessage);

  SDL_Rect mDest;
  mDest.x = x;
  mDest.y = y;
  mDest.w = surfaceMessage->w;
  mDest.h = surfaceMessage->h;

  SDL_RenderCopy(gRenderer, message, NULL, &mDest);

  SDL_FreeSurface(surfaceMessage);
  SDL_DestroyTexture(message);
}

void SDLGraphicsProgram::DrawSpriteImage(int x, int y, int w, int h,
                                         std::string image_filename,
                                         int char_width, int char_height,
                                         int row, int col) {
  ResourceManager::GetInstance().LoadResource("Assets/Sprites/" +
                                              image_filename);
  SDL_Texture* image = ResourceManager::GetInstance().GetTexture(
      gRenderer, "Assets/Sprites/" + image_filename);

  SDL_Rect mDest;
  mDest.x = x;
  mDest.y = y;
  mDest.w = w;
  mDest.h = h;

  // Define the rectangle that corresponds to the desired character in the
  // sprite sheet
  SDL_Rect srcRect = {char_width * col, char_height * row, char_width,
                      char_height};

  SDL_RenderCopy(gRenderer, image, &srcRect, &mDest);
}

void SDLGraphicsProgram::updateInputs() {
  SDL_Event e;
  SDL_StartTextInput();

  // Reset space and mouse-click every frame.
  m_keys[4] = false;
  m_keys[5] = false;

  if (SDL_PollEvent(&e) != 0) {
    switch (e.type) {
      case SDL_KEYDOWN:
        switch (e.key.keysym.sym) {
          case SDLK_LEFT:
            m_keys[0] = true;
            break;
          case SDLK_RIGHT:
            m_keys[1] = true;
            break;
          case SDLK_UP:
            m_keys[2] = true;
            break;
          case SDLK_DOWN:
            m_keys[3] = true;
            break;
          case SDLK_SPACE:
            m_keys[4] = true;
            break;
          case SDLK_r:
            m_keys[7] = true;
            break;
          default:
            break;
        }
        break;
      case SDL_KEYUP:
        switch (e.key.keysym.sym) {
          case SDLK_LEFT:
            m_keys[0] = false;
            break;
          case SDLK_RIGHT:
            m_keys[1] = false;
            break;
          case SDLK_UP:
            m_keys[2] = false;
            break;
          case SDLK_DOWN:
            m_keys[3] = false;
            break;
          case SDLK_r:
            m_keys[7] = false;
            break;
          case SDLK_SPACE:
            m_keys[4] = false;
            break;
          default:
            break;
        }
        break;
      case SDL_MOUSEBUTTONUP:
        m_keys[5] = true;
        break;
      case SDL_QUIT:
        m_keys[6] = true;
        break;
      default:
        break;
    }
  }

  SDL_StopTextInput();
}

bool SDLGraphicsProgram::getR() {return m_keys[7];}

bool SDLGraphicsProgram::getLeft() { return m_keys[0]; }

bool SDLGraphicsProgram::getRight() { return m_keys[1]; }

bool SDLGraphicsProgram::getUp() { return m_keys[2]; }

bool SDLGraphicsProgram::getDown() { return m_keys[3]; }

bool SDLGraphicsProgram::getSpace() { return m_keys[4]; }

bool SDLGraphicsProgram::getMouseClicked() { return m_keys[5]; }

std::pair<int, int> SDLGraphicsProgram::getMousePos() {
  int x, y;
  SDL_GetMouseState(&x, &y);
  return std::pair<int, int>(x, y);
}

bool SDLGraphicsProgram::getQuit() { return m_keys[6]; }

void SDLGraphicsProgram::PlayAudio(std::string audio_name) {
  ResourceManager::GetInstance().LoadAudio("Assets/Audio/" + audio_name);
  ResourceManager::GetInstance().PlayAudio();
}

void SDLGraphicsProgram::StopAudio() {
  ResourceManager::GetInstance().StopAudio();
}

// Creates a macro function that will be called
// whenever the module is imported into python
// 'mygameengine' is what we 'import' into python.
// 'm' is the interface (creates a py::module object)
//      for which the bindings are created.
//  The magic here is in 'template metaprogramming'
PYBIND11_MODULE(mygameengine, m) {
  m.doc() = "our game engine as a library";  // Optional docstring

  py::class_<SDLGraphicsProgram>(m, "SDLGraphicsProgram")
      .def(py::init<int, int>(), py::arg("w"), py::arg("h"))  // our constructor
      .def("clear", &SDLGraphicsProgram::clear)  // Expose member methods
      .def("delay", &SDLGraphicsProgram::delay)
      .def("flip", &SDLGraphicsProgram::flip)
      .def("loop", &SDLGraphicsProgram::loop)
      .def("DrawRectangle", &SDLGraphicsProgram::DrawRectangle)
      .def("DrawRectangleColor", &SDLGraphicsProgram::DrawRectangleColor)
      .def("DrawImage", &SDLGraphicsProgram::DrawImage)
      .def("updateInputs", &SDLGraphicsProgram::updateInputs)
      .def("getLeft", &SDLGraphicsProgram::getLeft)
      .def("getRight", &SDLGraphicsProgram::getRight)
      .def("getUp", &SDLGraphicsProgram::getUp)
      .def("getDown", &SDLGraphicsProgram::getDown)
      .def("getSpace", &SDLGraphicsProgram::getSpace)
      .def("getR", &SDLGraphicsProgram::getR)
      .def("getMouseClicked", &SDLGraphicsProgram::getMouseClicked)
      .def("getMousePos", &SDLGraphicsProgram::getMousePos)
      .def("getQuit", &SDLGraphicsProgram::getQuit)
      .def("PlayAudio", &SDLGraphicsProgram::PlayAudio)
      .def("StopAudio", &SDLGraphicsProgram::StopAudio)
      .def("DrawText", &SDLGraphicsProgram::DrawText)
      .def("DrawSpriteImage", &SDLGraphicsProgram::DrawSpriteImage);
  // We do not need to expose everything to our users!
  //            .def("getSDLWindow", &SDLGraphicsProgram::getSDLWindow,
  //            py::return_value_policy::reference)
}
