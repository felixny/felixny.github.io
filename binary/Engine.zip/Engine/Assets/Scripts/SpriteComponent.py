from Assets.Scripts import Component

class SpriteComponent(Component.Component):
    def __init__(self, spritePath, width, height, graphics, parent) -> None:
        Component.Component.__init__(self, parent)
        
        self.spritePath = spritePath
        self.width = width
        self.height = height
        self.graphics = graphics

    def main(self):
        if (self.parent.getTransformComponent() != None):
            self.graphics.DrawImage(self.parent.getTransformComponent().getX() * self.width, self.parent.getTransformComponent().getY() * self.height, self.width, self.height, self.spritePath)