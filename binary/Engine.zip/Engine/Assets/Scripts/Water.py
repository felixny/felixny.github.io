from Assets.Scripts import GameObject
from Assets.Scripts import SpriteComponent
from Assets.Scripts import TransformComponent

# Import Python's built-in "random" library for generating random numbers
import random

class Water(GameObject.GameObject):
    def __init__(self, x, y, width, height, graphics, game) -> None:
        """
        Constructor for the Water class.
        
        @param x: The x-coordinate of the water object.
        @param y: The y-coordinate of the water object.
        @param width: The width of the water object.
        @param height: The height of the water object.
        @param graphics: The graphics object used to render the water object.
        @param game: The game object that manages the water object.
        """
        GameObject.GameObject.__init__(self, x, y, width, height, graphics, game)
        
        # Add the water's SpriteComponent and TransformComponent
        self.addComponent(SpriteComponent.SpriteComponent("water.bmp", width, height, graphics, self))
        self.addComponent(TransformComponent.TransformComponent(x, y, self))

        # Set the water object's name
        self.name = "water"
