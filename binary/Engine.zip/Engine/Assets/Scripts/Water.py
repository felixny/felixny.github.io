from Assets.Scripts import GameObject
from Assets.Scripts import SpriteComponent
from Assets.Scripts import TransformComponent

# Now use some python libraries for random numbers!
import random

class Water(GameObject.GameObject):
    def __init__(self, x, y, width, height, graphics, game) -> None:
        GameObject.GameObject.__init__(self, x, y, width, height, graphics, game)
        self.addComponent(SpriteComponent.SpriteComponent("water.bmp", width, height, graphics, self))
        self.addComponent(TransformComponent.TransformComponent(x, y, self))

        self.name = "water"