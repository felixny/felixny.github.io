from Assets.Scripts import Component

class ColliderComponent(Component):
    def __init__(self, width, height):
        super().__init__()
        self.width = width
        self.height = height

    def isColliding(self, otherCollider, otherTransform):
        if (self.entity.transformComponent.x + self.width < otherTransform.x or
            self.entity.transformComponent.x > otherTransform.x + otherCollider.width or
            self.entity.transformComponent.y + self.height < otherTransform.y or
            self.entity.transformComponent.y > otherTransform.y + otherCollider.height):
            return False
        return True
