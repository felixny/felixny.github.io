# Run with:
#
# (Linux & Mac) python3.5 test.py -m ./mygameengine.so
# (Windows) python3.6 test.py -m ./mygameengine.pyd
#
# The program should also run with 'python2.7' but you will have
# to change the 3.5's to 2.7's in your respective build script as
# well as make sure you compiled with 3.5 or 2.7 load flags.
#
# You will see `python3.5-config --includes` for example which corresponds
# to which version of python you are building.
# (In fact, run `python3.5-config --includes` in the terminal to see what it does!)

import mygameengine

# Now use some python libraries for random numbers!
import random
from Assets.Scripts import Component

class GameObject:
    name = ""
    spriteComponent = None
    transformComponent = None
    
    def __init__(self, x, y, width, height, graphics, game) -> None:
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.graphics = graphics
        self.game = game

    def main(self):
        if self.spriteComponent != None:
            self.spriteComponent.main()
        if self.transformComponent != None:
            self.transformComponent.main()
    
    def addComponent(self, toAdd):
        if (str(type(toAdd)).find("SpriteComponent") != -1):
            self.spriteComponent = toAdd
        elif (str(type(toAdd)).find("TransformComponent") != -1):
            self.transformComponent = toAdd
        elif (str(type(toAdd)).find("ColliderComponent") != -1):
            self.colliderComponent = toAdd

    def getName(self):
        return self.name
    
    def getTransformComponent(self):
        return self.transformComponent
