import mygameengine

import random
from Assets.Scripts import Component

class GameObject:
    """Class representing a game object with a sprite and transform component."""

    name = ""
    spriteComponent = None
    transformComponent = None
    
    def __init__(self, x, y, width, height, graphics, game):
        """
        Constructor for the GameObject class.

        Args:
            x (float): The x coordinate of the game object.
            y (float): The y coordinate of the game object.
            width (float): The width of the game object.
            height (float): The height of the game object.
            graphics (Graphics): The graphics object to use for rendering.
            game (Game): The game object that the game object belongs to.
        """
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.graphics = graphics
        self.game = game

    def main(self):
        """
        Main function for the game object.

        Note:
            This function is called every frame to update the game object.
        """
        if self.spriteComponent != None:
            self.spriteComponent.main()
        if self.transformComponent != None:
            self.transformComponent.main()
    
    def addComponent(self, toAdd):
        """
        Adds a component to the game object.

        Note:
            This function adds the specified component to the game object based on its type.

        Args:
            toAdd (Component): The component to add to the game object.
        """
        if (str(type(toAdd)).find("SpriteComponent") != -1):
            self.spriteComponent = toAdd
        elif (str(type(toAdd)).find("TransformComponent") != -1):
            self.transformComponent = toAdd
        elif (str(type(toAdd)).find("ColliderComponent") != -1):
            self.colliderComponent = toAdd

    def getName(self):
        """
        Returns the name of the game object.

        Returns:
            str: The name of the game object.
        """
        return self.name
    
    def getTransformComponent(self):
        """
        Returns the transform component of the game object.

        Returns:
            TransformComponent: The transform component of the game object.
        """
        return self.transformComponent
