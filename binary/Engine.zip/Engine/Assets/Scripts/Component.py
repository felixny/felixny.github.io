class Component:
    """
    The base class for all components in a game engine or similar software.
    """
    
    def __init__(self, parent):
        """
        Constructor for the Component class.

        @param parent: The parent object that this component belongs to.
        @type parent: any
        """
        self.parent = parent
