from Assets.Scripts import GameObject
from Assets.Scripts import SpriteComponent
from Assets.Scripts import TransformComponent

# Now use some python libraries for random numbers!
import random

class Fire(GameObject.GameObject):
    def __init__(self, x, y, width, height, graphics, game) -> None:
        GameObject.GameObject.__init__(self, x, y, width, height, graphics, game)
        self.addComponent(SpriteComponent.SpriteComponent("fire.bmp", width, height, graphics, self))
        self.addComponent(TransformComponent.TransformComponent(x, y, self))

        self.name = "fire"
        self.timer = 0
        self.spreadTime = 40

    def main(self):
        GameObject.GameObject.main(self)

        cellElements = self.game.getElements()[self.y][self.x]
        for element in cellElements:
            # Extinguish
            if element.getName() == "water":
                i = 0
                while (i < len(cellElements)):
                    if (cellElements[i].getName() == "fire" or cellElements[i].getName() == "water"):
                        self.game.removeElement(cellElements[i], self.x, self.y)
                        i -= 1
                    i += 1
                return
        
        # Spread
        if (self.timer >= self.spreadTime):
            for spreadX in range(self.x - 1, self.x + 1 + 1):
                for spreadY in range(self.y - 1, self.y + 1 + 1):
                    if (spreadX >= 0 and spreadY >= 0 and spreadX < len(self.game.getElements()[0]) and spreadY < len(self.game.getElements())
                        and (bool(spreadX == self.x) ^ bool(spreadY == self.y))):
                        cellElements = self.game.getElements()[spreadY][spreadX]
                        for element in cellElements:
                            if (element.getName() == "wood" or element.getName() == "bush"):
                                self.game.addElement(Fire(spreadX, spreadY, self.width, self.height, self.graphics, self.game), spreadX, spreadY)
                                self.timer = 0
        self.timer += 1