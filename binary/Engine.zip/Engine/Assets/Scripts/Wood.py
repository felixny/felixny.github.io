from Assets.Scripts import GameObject
from Assets.Scripts import SpriteComponent
from Assets.Scripts import TransformComponent

# Now use some python libraries for random numbers!
import random

class Wood(GameObject.GameObject):
    def __init__(self, x, y, width, height, graphics, game) -> None:
        GameObject.GameObject.__init__(self, x, y, width, height, graphics, game)
        self.addComponent(SpriteComponent.SpriteComponent("wood.bmp", width, height, graphics, self))
        self.addComponent(TransformComponent.TransformComponent(x, y, self))

        self.name = "wood"
        self.burnTime = 100
    
    def main(self):
        GameObject.GameObject.main(self)

        cellElements = self.game.getElements()[self.y][self.x]
        for element in cellElements:
            # Extinguish
            if element.getName() == "fire":
                self.burnTime -= 1
                if (self.burnTime <= 0):
                    i = 0
                    while (i < len(cellElements)):
                        if (cellElements[i].getName() == "wood" or cellElements[i].getName() == "fire"):
                            self.game.removeElement(cellElements[i], self.x, self.y)
                            i -= 1
                        i += 1
                    return