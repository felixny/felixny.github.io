from Assets.Scripts import Component

class TransformComponent(Component.Component):
    def __init__(self, x, y, parent) -> None:
        Component.Component.__init__(self, parent)
        
        self.x = x
        self.y = y

    def main(self):
        return
    
    def getX(self):
        return self.x
    
    def getY(self):
        return self.y