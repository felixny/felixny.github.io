# Run with:
#
# (Linux & Mac) python3.5 test.py -m ./mygameengine.so
# (Windows) python3.6 test.py -m ./mygameengine.pyd
#
# The program should also run with 'python2.7' but you will have
# to change the 3.5's to 2.7's in your respective build script as
# well as make sure you compiled with 3.5 or 2.7 load flags.
#
# You will see `python3.5-config --includes` for example which corresponds
# to which version of python you are building.
# (In fact, run `python3.5-config --includes` in the terminal to see what it does!)
import mygameengine
from Assets.Scripts import GameObject

# Now use some python libraries for random numbers!
import random

class Character(GameObject.GameObject):
    def __init__(self, x, y, width, height, graphics, game) -> None:
        GameObject.GameObject.__init__(self, x, y, width, height, graphics, game)
        
        self.name = "character"
        self.sprite = "character.bmp"
        #self.timer = 0
        #self.spreadTime = 40

    def main(self):
        GameObject.GameObject.main(self)

        cellElements = self.game.getElements()[self.y][self.x]
        for element in cellElements:
            # Character dies 
            if element.getName() == "fire":
                i = 0
                while (i < len(cellElements)):
                    if (cellElements[i].getName() == "character" or cellElements[i].getName() == "fire"):
                        self.game.removeElement(cellElements[i], self.x, self.y)
                        i -= 1
                    i += 1
                return
        
        # Spread
        # if (self.timer >= self.spreadTime):
        #     for spreadX in range(self.x - 1, self.x + 1 + 1):
        #         for spreadY in range(self.y - 1, self.y + 1 + 1):
        #             if (spreadX >= 0 and spreadY >= 0 and spreadX < len(self.game.getElements()[0]) and spreadY < len(self.game.getElements())
        #                 and (bool(spreadX == self.x) ^ bool(spreadY == self.y))):
        #                 cellElements = self.game.getElements()[spreadY][spreadX]
        #                 for element in cellElements:
        #                     if (element.getName() == "wood" or element.getName() == "bush"):
        #                         self.game.addElement(Fire(spreadX, spreadY, self.width, self.height, self.graphics, self.game), spreadX, spreadY)
        #                         self.timer = 0
        #self.timer += 1