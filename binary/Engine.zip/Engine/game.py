# Run with:
#
# (Linux & Mac) python3.5 test.py -m ./mygameengine.so
# (Windows) python3.6 test.py -m ./mygameengine.pyd
#
# The program should also run with 'python2.7' but you will have
# to change the 3.5's to 2.7's in your respective build script as
# well as make sure you compiled with 3.5 or 2.7 load flags.
#
# You will see `python3.5-config --includes` for example which corresponds
# to which version of python you are building.
# (In fact, run `python3.5-config --includes` in the terminal to see what it does!)
import mygameengine
from Assets.Scripts import Fire
from Assets.Scripts import Water
from Assets.Scripts import Wood
from Assets.Scripts import Bush
from Assets.Scripts import Character

# Now use some python libraries for random numbers!
import random
import time

class Treasure:
    def __init__(self, x, y, cellWidth, cellHeight, graphics):
        self.x = x
        self.y = y
        self.cellWidth = cellWidth
        self.cellHeight = cellHeight
        self.graphics = graphics
        self.found = False
        self.graphics.DrawImage(self.x, self.y, self.cellWidth, self.cellHeight, "treasure.bmp")
        print("Creating treasure at", self.x, self.y)

    
    def collect(self):
        self.found = True
        self.graphics.DrawText(int(self.x/2), int(self.y/2), 'You found the treasure!', 28)

    def can_collect(self, x, y, width, height):
        # Check if any part of the player's position overlaps with any part of the treasure's position
        if (x + width >= self.x and x < self.x + self.cellWidth) and (y + height >= self.y and y < self.y + self.cellHeight):
            return True
        return False
    
    def generate_new_wall(self):
        while True:
            wall_x = random.randint(1, self.screenWidth - 2) * self.cellWidth
            wall_y = random.randint(1, self.screenHeight - 2) * self.cellHeight
            for wall in self.walls:
                if (wall_x, wall_y) == wall:
                    # The new wall overlaps with an existing wall, generate a new location
                    break
            else:
                # The new wall does not overlap with any existing walls, add it to the list and draw it
                self.walls.append((wall_x, wall_y))
                Wall(wall_x, wall_y, self.cellWidth, self.cellHeight, self.graphics)
                break

class Wall:
    def __init__(self, x, y, cellWidth, cellHeight, graphics):
        self.x = x
        self.y = y
        self.cellWidth = cellWidth
        self.cellHeight = cellHeight
        self.graphics = graphics
        self.graphics.DrawImage(self.x, self.y, self.cellWidth, self.cellHeight, "stone.bmp")


class CharacterAnimator:

    characterWidth = 31
    characterHeight = 47

    def __init__(self, cellWidth, cellHeight, graphics, screenHeight, screenWidth) -> None:
        self.cellWidth = cellWidth
        self.cellHeight = cellHeight
        self.graphics = graphics
        self.screenHeight = screenHeight
        self.screenWidth = screenWidth

        self.xPos = (self.screenWidth // 2) * self.cellWidth
        self.yPos = (self.screenHeight // 2) * self.cellHeight
        self.xFacing = 0
        self.yFacing = 0
        self.moving = False

        self.start_time = time.time()  # Store the start time for the timer
        self.timer_duration = 30  # Duration of the timer in seconds
        self.timer_expired = False  # Flag to track if the timer has expired
        self.game_over = False  # Flag to track if the game is over
        self.treasure_count = 0

        # Generate random walls
        self.walls = []
        for i in range(30):
            x = random.randint(1, self.screenWidth - 2) * self.cellWidth
            y = random.randint(1, self.screenHeight - 2) * self.cellHeight
            self.walls.append((x, y))
            Wall(x, y, self.cellWidth, self.cellHeight, self.graphics)
         # Generate treasure
        self.treasure = []
        for i in range(2):
            treasure_x, treasure_y = self.generate_random_location()
            self.treasure.append(Treasure(treasure_x, treasure_y, self.cellWidth, self.cellHeight, self.graphics))

    def reset_game(self):
        # Reset game state
        self.start_time = time.time()
        self.timer_expired = False
        self.game_over = False
        self.treasure_count = 0
        self.walls = []
        self.treasure = []

        # Generate random walls
        for i in range(30):
            x = random.randint(1, self.screenWidth - 2) * self.cellWidth
            y = random.randint(1, self.screenHeight - 2) * self.cellHeight
            self.walls.append((x, y))
            Wall(x, y, self.cellWidth, self.cellHeight, self.graphics)

        # Generate treasure
        for i in range(2):
            treasure_x, treasure_y = self.generate_random_location()
            self.treasure.append(Treasure(treasure_x, treasure_y, self.cellWidth, self.cellHeight, self.graphics))
    
    def update_timer(self):
        elapsed_time = time.time() - self.start_time  # Calculate elapsed time
        remaining_time = max(0, self.timer_duration - elapsed_time)  # Calculate remaining time
        if remaining_time <= 0:
            self.timer_expired = True  # Set timer_expired flag to True when timer expires
            self.game_over = True
            self.graphics.DrawText(256,10,'Game Over: Press R to restart',50)
        else:
            # Draw remaining time on screen
            self.graphics.DrawText(256, 10, 'Time Remaining: {:.1f} seconds'.format(remaining_time), 20)
            self.graphics.DrawText(720, 10, 'Treasure Count: {}'.format(self.treasure_count), 20)  # Update treasure count

    def generate_random_location(self):
        while True:
            treasure_x = random.randint(1, self.screenWidth - 2) * self.cellWidth
            treasure_y = random.randint(1, self.screenHeight - 2) * self.cellHeight
            if not any(t.x == treasure_x and t.y == treasure_y for t in self.treasure) and not any(wall_x <= treasure_x < wall_x + self.cellWidth and wall_y <= treasure_y < wall_y + self.cellHeight for wall_x, wall_y in self.walls):
                return treasure_x, treasure_y

    def can_move_to(self, x, y):
        # Check if the move is within the bounds of the screen
        if x < 0 or y < 0 or x >= self.screenWidth * self.cellWidth or y >= self.screenHeight * self.cellHeight:
            return False
        # Check if the move would collide with any walls
        for wall_x, wall_y in self.walls:
            if (x >= wall_x and x < wall_x + self.cellWidth and y >= wall_y and y < wall_y + self.cellHeight):
                return False
        return True
    


    def main(self):

        self.update_timer()
        # Check if the character was moved in the game environment


        if self.game_over:
            self.moving = False

        if (self.graphics.getUp() and self.yPos > 0) and self.can_move_to(self.xPos, self.yPos - self.cellHeight):
            self.xFacing = 0
            self.yFacing = -1
            self.moving = True
        elif (self.graphics.getDown() and self.yPos < (self.screenHeight - 1) * self.cellHeight) and self.can_move_to(self.xPos, self.yPos + self.cellHeight):
            self.xFacing = 0
            self.yFacing = 1
            self.moving = True
        elif (self.graphics.getLeft() and self.xPos > 0) and self.can_move_to(self.xPos - self.cellWidth, self.yPos) :
            self.xFacing = -1
            self.yFacing = 0
            self.moving = True
        elif (self.graphics.getRight() and self.xPos < (self.screenWidth - 1) * self.cellWidth) and self.can_move_to(self.xPos + self.cellWidth, self.yPos):
            self.xFacing = 1
            self.yFacing = 0
            self.moving = True

        if (self.moving == True):
            # self.graphics.PlayAudio("move.wav")
            # time.sleep(0.1)
            
            # Move character
            self.xPos += self.xFacing * self.cellWidth // 2
            self.yPos += self.yFacing * self.cellHeight // 2
            
            self.graphics.StopAudio()
        self.moving = False

    
        # Draw walls and character
        for wall in self.walls:
            Wall(wall[0], wall[1], self.cellWidth, self.cellHeight, self.graphics)
        
         # Draw treasure and character
        for treasure in self.treasure:
            if not treasure.found:
                self.graphics.DrawImage(treasure.x, treasure.y, self.cellWidth, self.cellHeight, "treasure.bmp")

       # Check if the character has collected any treasure
        # Check if the character has collected any treasure
        for t in self.treasure:
            if t.found:
                continue
            if t.can_collect(self.xPos, self.yPos, self.characterWidth, self.characterHeight):
                t.collect()
                self.treasure_count += 1
                

                # Generate a new treasure randomly
                while True:
                    new_treasure_x, new_treasure_y = self.generate_random_location()
                    if (new_treasure_x, new_treasure_y) not in self.walls:
                        break
                new_treasure = Treasure(new_treasure_x, new_treasure_y, self.cellWidth, self.cellHeight, self.graphics)
                self.treasure.append(new_treasure)

                # Remove the collected treasure from the list
                self.treasure.remove(t)

                # Generate new walls randomly
                self.walls = []
                for i in range(30):
                    x = random.randint(1, self.screenWidth - 2) * self.cellWidth
                    y = random.randint(1, self.screenHeight - 2) * self.cellHeight
                    if x == self.cellWidth and y == self.cellHeight: # top-left corner
                        continue
                    self.walls.append((x, y))
                    Wall(x, y, self.cellWidth, self.cellHeight, self.graphics)

        if (self.xFacing == 0 and self.yFacing == -1):
            j = 0
            for i in range(0, self.cellHeight // 2, 16):
                j = (j+1) % 4
                self.graphics.DrawSpriteImage(self.xPos, self.yPos - i, self.cellWidth, self.cellHeight, "character.bmp", 31, 47, 3, j)
                self.xFacing = 0
                self.yFacing = 0
                # time.sleep(0.1)
            return
        elif (self.xFacing == 0 and self.yFacing == 1):
            j = 0
            for i in range(0, self.cellHeight // 2, 16):
                j = (j+1) % 4
                self.graphics.DrawSpriteImage(self.xPos, self.yPos + i, self.cellWidth, self.cellHeight, "character.bmp", 31, 47, 0, j)
                self.xFacing = 0
                self.yFacing = 0
                # time.sleep(0.1)
            return
        elif (self.xFacing == -1 and self.yFacing == 0):
            j = 0
            for i in range(0, self.cellWidth // 2, 16):
                j = (j+1) % 4
                self.graphics.DrawSpriteImage(self.xPos - i, self.yPos, self.cellWidth, self.cellHeight, "character.bmp", 31, 47, 1, j)
                self.xFacing = 0
                self.yFacing = 0
                # time.sleep(0.1)
            return
        elif (self.xFacing == 1 and self.yFacing == 0):
            j = 0
            for i in range(0, self.cellWidth // 2, 16):
                j = (j+1) % 4
                self.graphics.DrawSpriteImage(self.xPos + i, self.yPos, self.cellWidth, self.cellHeight, "character.bmp", 31, 47, 2, j)
                self.xFacing = 0
                self.yFacing = 0
                # time.sleep(0.1)
            return
        
        #Draw Character on screen
        self.graphics.DrawSpriteImage(self.xPos, self.yPos, self.cellWidth, self.cellHeight, "character.bmp", self.characterWidth, self.characterHeight, 0, 0)

        
    
    def getX(self):
        return (int)(self.xPos / self.cellWidth)

    def getY(self):
        return (int)(self.yPos / self.cellHeight)
    
    def getXFacing(self):
        return self.xFacing
    
    def getYFacing(self):
        return self.yFacing
        


class Inventory:
    tools = [["fire.bmp", "water.bmp"], ["wood.bmp", "bush.bmp"]]
    toolsHeight = len(tools)
    toolsWidth = len(tools[0]) if (toolsHeight > 0) else 0
    selectedTool = None

    def __init__(self, cellWidth, cellHeight, graphics) -> None:
        self.cellWidth = cellWidth
        self.cellHeight = cellHeight
        self.graphics = graphics

    def main(self):
        drawX = 0
        drawY = 0
        
        # Draw tools
        for row in self.tools:
            for col in row:
                self.graphics.DrawRectangleColor(drawX,drawY,self.cellWidth,self.cellHeight, 0xFF00FF, False)
                if (col != None):
                    self.graphics.DrawImage(drawX, drawY, self.cellWidth, self.cellHeight, col)
                drawX += self.cellWidth
            drawX = 0
            drawY += self.cellHeight

        # Check if a tool has been selected.
        mousePos = self.graphics.getMousePos()
        if (self.graphics.getMouseClicked()):
            mouseX = (int)(mousePos[0] / self.cellWidth)
            mouseY = (int)(mousePos[1] / self.cellHeight)
            if (mouseX >= 0 and mouseX <= self.toolsWidth - 1 and mouseY >= 0 and mouseY <= self.toolsHeight - 1):
                self.selectedTool = self.tools[mouseY][mouseX]
    
    def getSelectedTool(self):
        return self.selectedTool
    
class Game:
    def __init__(self, screenWidth, screenHeight, cellWidth, cellHeight) -> None:
        self.screenWidth = screenWidth
        self.screenHeight = screenHeight
        self.cellWidth = cellWidth
        self.cellHeight = cellHeight
        self.startGame = True

        #self.elements = [[[]] * self.screenWidth] * self.screenHeight
        self.elements = [[[] for col in range(self.screenWidth)] for row in range(self.screenHeight)]

        # Initialize SDL
        self.graphics = mygameengine.SDLGraphicsProgram(self.screenWidth * self.cellWidth, self.screenHeight * self.cellHeight)

        # Create inventory
        self.inventory = Inventory(self.cellWidth, self.cellHeight, self.graphics)

        #Create Character Animator
        self.animator = CharacterAnimator(self.cellWidth, self.cellHeight, self.graphics, self.screenHeight, self.screenWidth)

        # Play music
        # self.graphics.PlayAudio("BabyElephantWalk60.wav");
        
        # Our main game loop
        print("Setting up game loop")
        while (self.graphics.getQuit() == False):
            self.main()
    
    def main(self):
        selectedTool = self.inventory.getSelectedTool()

        # Clear the screen
        self.graphics.clear()
        self.inventory.main()
        self.animator.main()

        # Draw elements.
        for row in self.elements:
            for cell in row:
                for element in cell:
                    element.main()

        # Draw selected tool.
        self.graphics.DrawRectangleColor(0, (self.screenHeight - 1) * self.cellHeight, self.cellWidth, self.cellHeight, 0xFF00FF, False)
        if (selectedTool != None):
            self.graphics.DrawImage(0, (self.screenHeight - 1) * self.cellHeight, self.cellWidth, self.cellHeight, selectedTool)
        
        # Check for changes in user inputs
        self.graphics.updateInputs()

        if (self.graphics.getR()):
            print("reset key")
            self.animator.reset_game()

        # Place elements.
        if (self.graphics.getSpace()):
            # Determine where to spawn the new element.
            x = self.animator.getX() + self.animator.getXFacing()
            y = self.animator.getY() + self.animator.getYFacing()

            if (selectedTool == "fire.bmp"):
                self.elements[y][x].append(Fire.Fire(x, y, self.cellWidth, self.cellHeight, self.graphics, self))
            elif (selectedTool == "water.bmp"):
                self.elements[y][x].append(Water.Water(x, y, self.cellWidth, self.cellHeight, self.graphics, self))
            elif (selectedTool == "wood.bmp"):
                self.elements[y][x].append(Wood.Wood(x, y, self.cellWidth, self.cellHeight, self.graphics, self))
            elif (selectedTool == "bush.bmp"):
                self.elements[y][x].append(Bush.Bush(x, y, self.cellWidth, self.cellHeight, self.graphics, self))


        # Add a little delay
        #self.graphics.delay(10)
        # Refresh the screen
        self.graphics.flip()
    
    def getElements(self):
        return self.elements
    
    def addElement(self, toAppend, col, row):
        self.elements[row][col].append(toAppend)
    
    def removeElement(self, toRemove, col, row):
        self.elements[row][col].remove(toRemove)

# Run program
game = Game(16, 9, 64, 64)
