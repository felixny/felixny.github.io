#include "ResourceManager.hpp"

#include <iostream>
#include <iterator>

/**
 * @brief Constructs a new ResourceManager object.
 */
ResourceManager::ResourceManager() {
  std::cout << "Resource Manager created" << std::endl;
  // std::cout << "Adding new resource " << text << " to the map" << std::endl;
}

/**
  * @brief Destructs a ResourceManager object and deletes the loaded resources.
  */
ResourceManager::~ResourceManager() {
  // delete the texture
  Destroy();
}

/**
  * @brief Loads a resource into the loaded resources map.
  * 
  * @param image_filename The filename of the resource to load.
  */
void ResourceManager::LoadResource(std::string image_filename) {
  // Check if the resource has already been loaded
  std::lock_guard<std::mutex> lock(map_mutex);
  auto it = loaded_resources.find(image_filename);
  if (it != loaded_resources.end()) {
    // Resource has already been loaded, no need to load again
    return;
  }

  // Load the resource and add it to the loaded resources map
  SDL_Surface* surface = SDL_LoadBMP(image_filename.c_str());
  if (surface != nullptr) {
    loaded_resources[image_filename] = surface;
    std::cout << "Loaded resource " << image_filename << std::endl;
  } else {
    std::cerr << "Error loading resource: " << image_filename << std::endl;
  }

  // for (const auto& entry : loaded_resources) {
  //   std::cout << "Key: " << entry.first << ", Value: " << entry.second
  //             << std::endl;
  // }
}

/**
  * @brief Retrieves a loaded resource from the loaded resources map.
  * 
  * @param image_filename The filename of the resource to retrieve.
  * @return The loaded SDL_Surface object associated with the given filename.
  */
SDL_Surface* ResourceManager::GetResource(std::string image_filename) {
  /*std::cout << "Retrieved saved copy of " << image_filename
            << " from GetResource\n";*/
  return mSpriteSheet;
}

/**
  * @brief Loads the texture.
  * 
  * @param renderer The SDL_Renderer object to use for creating the texture.
  */
void ResourceManager::LoadTexture(SDL_Renderer* renderer) {
  mTexture = SDL_CreateTextureFromSurface(renderer, mSpriteSheet);
  if (nullptr == mTexture) {
    std::cerr << "Error creating texture\n";
  } else {
    std::cout << "SDL_Texture allocated\n";
  }
}

/**
 * @brief Get the texture associated with the given image filename.
 * @param renderer The SDL_Renderer to use for creating the texture.
 * @param image_filename The filename of the image to load.
 * @return The loaded SDL_Texture or nullptr if there was an error.
 */
SDL_Texture* ResourceManager::GetTexture(SDL_Renderer* renderer,
                                         std::string image_filename) {
  // Check if the texture has already been created
  auto it = loaded_textures.find(image_filename);
  if (it != loaded_textures.end()) {
    // Texture has already been created, return it
    return it->second;
  }

  // Load the texture and add it to the loaded textures map
  SDL_Surface* surface = loaded_resources[image_filename];
  SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);
  if (texture != nullptr) {
    loaded_textures[image_filename] = texture;
    std::cout << "Created texture for " << image_filename << std::endl;
    return texture;
  } else {
    std::cerr << "Error creating texture for " << image_filename << std::endl;
    return nullptr;
  }
}

/**
 * @brief Get the singleton instance of the ResourceManager.
 * @return The singleton ResourceManager instance.
 */
ResourceManager& ResourceManager::GetInstance() {
  static ResourceManager s_instance;
  return s_instance;
}

/**
 * @brief Destroy all loaded textures and resources.
 */
void ResourceManager::Destroy() {
  for (auto& texture : loaded_textures) {
    std::cout << "Destroying texture: " << texture.first << std::endl;
    SDL_DestroyTexture(texture.second);
  }
  loaded_textures.clear();

  for (auto& resource : loaded_resources) {
    std::cout << "Freeing surface: " << resource.first << std::endl;
    SDL_FreeSurface(resource.second);
  }
  loaded_resources.clear();
}

/**
 * @brief Start up the ResourceManager.
 * @return 0 if the ResourceManager started up successfully.
 */
int ResourceManager::StartUp() { return 0; }

/**
 * @brief Shut down the ResourceManager.
 * @return 0 if the ResourceManager started up successfully.
 */
int ResourceManager::ShutDown() { return 0; }

/**
 * @brief A test function to ensure the singleton is working.
 */
void ResourceManager::printMessage() {
  std::cout << "Singleton works!" << std::endl;
}

/**
 * @brief Load an audio file.
 * @param audio_filename The filename of the audio file to load.
 */
void ResourceManager::LoadAudio(std::string audio_filename) {
  // Check if the audio file has already been loaded
  auto it = audioMap.find(audio_filename);
  if (it != audioMap.end()) {
    // Resource has already been loaded, use the existing audio
    std::cout << "Found resource " << audio_filename
              << " utilizing previously loaded resource\n";
    wavSpec = it->second;
    return;
  }

  // Resource has not been loaded yet, create a new thread to load it
  std::thread loading_thread([this, audio_filename]() {
    std::cout << "Loading new audio resource " << audio_filename << std::endl;
    SDL_AudioSpec* tempWavSpec =
        SDL_LoadWAV(audio_filename.c_str(), &wavSpec, &wavBuffer, &wavLength);
    if (tempWavSpec != nullptr) {
      // Resource loaded successfully, add it to the map
      std::lock_guard<std::mutex> lock(map_mutex);
      audioMap[audio_filename] = *tempWavSpec;
      wavSpec = *tempWavSpec;
      std::cout << "SDL_LoadWAV allocated\n";
    } else {
      // Resource failed to load
      std::cerr << "Error loading resource: " << audio_filename
                << SDL_GetError() << std::endl;
    }
  });

  // Detach the thread and continue execution of the main thread
  loading_thread.detach();
}

/**
 * @brief Play the current loaded audio file.
 */
void ResourceManager::PlayAudio() {
  // open audio device

  deviceId = SDL_OpenAudioDevice(NULL, 0, &wavSpec, NULL, 0);

  if (deviceId == 0) {
    std::cout << "Couldn't play audio file " << SDL_GetError() << std::endl;
  } else {
    // play audio

    int success = SDL_QueueAudio(deviceId, wavBuffer, wavLength);
    if (success == 0) {
      SDL_PauseAudioDevice(deviceId, 0);
    } else {
      std::cout << "Couldn't play audio file " << SDL_GetError() << std::endl;
    }
  }
}

/**
 * @brief Stop the currently playing audio file.
 */
void ResourceManager::StopAudio() { SDL_PauseAudioDevice(deviceId, 1); }