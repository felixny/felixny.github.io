var searchData=
[
  ['x_0',['x',['../class_game_object_1_1_game_object.html#a0c79e3615c9668164bf9aa933f6c1057',1,'GameObject.GameObject.x()'],['../class_transform_component_1_1_transform_component.html#a2fd0e73eda14cc28d8bfbdfd2ba677d0',1,'TransformComponent.TransformComponent.x()']]]
];
