var searchData=
[
  ['y_0',['y',['../class_game_object_1_1_game_object.html#a5cbb31e17ce301e93c42ea30a2616d0f',1,'GameObject.GameObject.y()'],['../class_transform_component_1_1_transform_component.html#a161aa6a774ac102522055a7212e60a63',1,'TransformComponent.TransformComponent.y()']]]
];
