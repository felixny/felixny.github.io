var searchData=
[
  ['game_0',['game',['../class_game_object_1_1_game_object.html#a61c6a263d89c17991e152fb828bd2da5',1,'GameObject::GameObject']]],
  ['graphics_1',['graphics',['../class_game_object_1_1_game_object.html#ab71941daa15de24380867cbc5d824be2',1,'GameObject.GameObject.graphics()'],['../class_sprite_component_1_1_sprite_component.html#a0224efbd6d6976a789b458b9eefdde5c',1,'SpriteComponent.SpriteComponent.graphics()']]],
  ['grenderer_2',['gRenderer',['../class_s_d_l_graphics_program.html#ac74067b7b7574fb16ef05c550cdbc7e2',1,'SDLGraphicsProgram']]],
  ['gwindow_3',['gWindow',['../class_s_d_l_graphics_program.html#a2db5103a225411ec5da1592a02e26d23',1,'SDLGraphicsProgram']]]
];
