import mygameengine
from Assets.Scripts import GameObject

# Now use some python libraries for random numbers!
import random

class Character(GameObject.GameObject):
    def __init__(self, x, y, width, height, graphics, game) -> None:
        """
        Constructor for Character class.
        
        :param x: The x-coordinate of the character.
        :param y: The y-coordinate of the character.
        :param width: The width of the character.
        :param height: The height of the character.
        :param graphics: The graphics engine used to render the character.
        :param game: The game engine that the character belongs to.
        """
        GameObject.GameObject.__init__(self, x, y, width, height, graphics, game)
        
        self.name = "character"
        self.sprite = "character.bmp"
        #self.timer = 0
        #self.spreadTime = 40

    def main(self):
        """
        The main function of the Character class.
        """
        GameObject.GameObject.main(self)

        cellElements = self.game.getElements()[self.y][self.x]
        for element in cellElements:
            # Character dies 
            if element.getName() == "fire":
                i = 0
                while (i < len(cellElements)):
                    if (cellElements[i].getName() == "character" or cellElements[i].getName() == "fire"):
                        self.game.removeElement(cellElements[i], self.x, self.y)
                        i -= 1
                    i += 1
                return
