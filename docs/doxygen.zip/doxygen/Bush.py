from Assets.Scripts import GameObject
from Assets.Scripts import SpriteComponent
from Assets.Scripts import TransformComponent

class Bush(GameObject.GameObject):
    """
    A class representing a bush game object.
    """
    def __init__(self, x, y, width, height, graphics, game) -> None:
        """
        Initializes a new instance of the Bush class.

        Parameters:
            x (int): The x-coordinate of the bush.
            y (int): The y-coordinate of the bush.
            width (int): The width of the bush.
            height (int): The height of the bush.
            graphics (Graphics): The graphics object to use for rendering.
            game (Game): The game object this bush belongs to.
        """
        GameObject.GameObject.__init__(self, x, y, width, height, graphics, game)
        self.addComponent(SpriteComponent.SpriteComponent("bush.bmp", width, height, graphics, self))
        self.addComponent(TransformComponent.TransformComponent(x, y, self))

        self.name = "bush"
        self.burnTime = 50
    
    def main(self):
        """
        The main function of the bush game object.
        """
        GameObject.GameObject.main(self)

        cellElements = self.game.getElements()[self.y][self.x]
        for element in cellElements:
            # Extinguish
            if element.getName() == "fire":
                self.burnTime -= 1
                if (self.burnTime <= 0):
                    i = 0
                    while (i < len(cellElements)):
                        if (cellElements[i].getName() == "bush" or cellElements[i].getName() == "fire"):
                            self.game.removeElement(cellElements[i], self.x, self.y)
                            i -= 1
                        i += 1
                    return
