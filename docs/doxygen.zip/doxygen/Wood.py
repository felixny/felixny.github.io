from Assets.Scripts import GameObject
from Assets.Scripts import SpriteComponent
from Assets.Scripts import TransformComponent

# Import Python's built-in "random" library for generating random numbers
import random

class Wood(GameObject.GameObject):
    def __init__(self, x, y, width, height, graphics, game) -> None:
        """
        Constructor for the Wood class.
        
        @param x: The x-coordinate of the wood object.
        @param y: The y-coordinate of the wood object.
        @param width: The width of the wood object.
        @param height: The height of the wood object.
        @param graphics: The graphics object used to render the wood object.
        @param game: The game object that manages the wood object.
        """
        GameObject.GameObject.__init__(self, x, y, width, height, graphics, game)
        
        # Add the wood's SpriteComponent and TransformComponent
        self.addComponent(SpriteComponent.SpriteComponent("wood.bmp", width, height, graphics, self))
        self.addComponent(TransformComponent.TransformComponent(x, y, self))

        # Set the wood object's name and burn time
        self.name = "wood"
        self.burnTime = 100
    
    def main(self):
        """
        The main method of the Wood class, which is called each game tick.
        """
        GameObject.GameObject.main(self)

        # Get the list of elements in the current cell of the wood object
        cellElements = self.game.getElements()[self.y][self.x]
        for element in cellElements:
            # Extinguish the fire element, if present
            if element.getName() == "fire":
                self.burnTime -= 1
                if (self.burnTime <= 0):
                    # Remove all wood and fire elements from the cell
                    i = 0
                    while (i < len(cellElements)):
                        if (cellElements[i].getName() == "wood" or cellElements[i].getName() == "fire"):
                            self.game.removeElement(cellElements[i], self.x, self.y)
                            i -= 1
                        i += 1
                    return
