from Assets.Scripts import Component

class ColliderComponent(Component):
    """
    A component that enables collision detection with other objects in the game.
    """
    
    def __init__(self, width, height):
        """
        Constructor for the ColliderComponent class.

        @param width: The width of the collider component.
        @type width: int
        @param height: The height of the collider component.
        @type height: int
        """
        super().__init__()
        self.width = width
        self.height = height

    def isColliding(self, otherCollider, otherTransform):
        """
        Checks if this collider component is colliding with another.

        @param otherCollider: The collider component of the other object.
        @type otherCollider: ColliderComponent
        @param otherTransform: The transform component of the other object.
        @type otherTransform: TransformComponent
        @return: True if colliding, False otherwise.
        @rtype: bool
        """
        if (self.entity.transformComponent.x + self.width < otherTransform.x or
            self.entity.transformComponent.x > otherTransform.x + otherCollider.width or
            self.entity.transformComponent.y + self.height < otherTransform.y or
            self.entity.transformComponent.y > otherTransform.y + otherCollider.height):
            return False
        return True
