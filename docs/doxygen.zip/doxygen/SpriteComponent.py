from Assets.Scripts import Component

class SpriteComponent(Component.Component):
    def __init__(self, spritePath, width, height, graphics, parent) -> None:
        """
        Constructor for the SpriteComponent class.
        
        @param spritePath: The path to the sprite image file.
        @param width: The width of the sprite image.
        @param height: The height of the sprite image.
        @param graphics: The graphics object used to draw the sprite image.
        @param parent: The parent object that this SpriteComponent belongs to.
        """
        Component.Component.__init__(self, parent)
        
        # Set the sprite path, width, height, and graphics object
        self.spritePath = spritePath
        self.width = width
        self.height = height
        self.graphics = graphics

    def main(self):
        """
        The main function of the SpriteComponent class.
        
        This function draws the sprite image at the current x and y coordinates of the parent object.
        """
        if (self.parent.getTransformComponent() != None):
            self.graphics.DrawImage(self.parent.getTransformComponent().getX() * self.width, self.parent.getTransformComponent().getY() * self.height, self.width, self.height, self.spritePath)
