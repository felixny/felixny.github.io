from Assets.Scripts import Component

class TransformComponent(Component.Component):
    def __init__(self, x, y, parent) -> None:
        """
        Constructor for the TransformComponent class.
        
        @param x: The initial x-coordinate of the object that this TransformComponent belongs to.
        @param y: The initial y-coordinate of the object that this TransformComponent belongs to.
        @param parent: The parent object that this TransformComponent belongs to.
        """
        Component.Component.__init__(self, parent)
        
        # Set the initial x and y coordinates of the parent object
        self.x = x
        self.y = y

    def main(self):
        """
        The main function of the TransformComponent class.
        
        This function does nothing and is provided for consistency with other components.
        """
        return
    
    def getX(self):
        """
        Returns the x-coordinate of the parent object.
        
        @return: The x-coordinate of the parent object.
        """
        return self.x
    
    def getY(self):
        """
        Returns the y-coordinate of the parent object.
        
        @return: The y-coordinate of the parent object.
        """
        return self.y
